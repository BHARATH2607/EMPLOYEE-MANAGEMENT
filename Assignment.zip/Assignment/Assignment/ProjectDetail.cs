﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnment
{
    class ProjectDetail
    {
        public int ProjId;
        public string ProjName;
        public string ManagerId;

        public ProjectDetail()
        {
            Console.WriteLine("Enter the Project Id");
            ProjId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Project Name");
            ProjName = Console.ReadLine();
            Console.WriteLine("Enter the Manager Id");
            ManagerId = Console.ReadLine();
        }

        public override string ToString()
        {
            return ManagerId.ToString().PadLeft(20) + "|" + ProjId.ToString().PadLeft(20) + "|" +
               ProjName.PadLeft(20) + "\n";
        }
    }
}
