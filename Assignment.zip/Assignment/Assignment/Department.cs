﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnment
{
    class Department
    {
        public int DeptId;
        public string DeptName;
        public int NoofProjects;

        public Department()
        {
            Console.WriteLine("Enter the Department Id");
            DeptId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Department Name");
            DeptName = Console.ReadLine();
            Console.WriteLine("Enter the Number of Projects");
            NoofProjects = int.Parse(Console.ReadLine());
        }

        public override string ToString()
        {
            return DeptId.ToString().PadLeft(20) + "|" + DeptName.PadLeft(20) + "|" +
                    NoofProjects.ToString().PadLeft(20) + "\n";
        }
    }
}
