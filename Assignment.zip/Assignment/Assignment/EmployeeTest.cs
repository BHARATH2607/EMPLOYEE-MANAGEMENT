﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assissnment
{
    class EmployeeTest
    {
        public static string filename = @"C:\Users\Bharath\System Apps\Desktop\EmployeeRecords.txt";
        public static string departfile = @"C:\Users\Bharath\System Apps\Desktop\DepartmentRecords.txt";
        public static string projectsfile = @"C:\Users\Bharath\System Apps\Desktop\ProjectsRecords.txt";

        public void BasedOnDepartName()
        {
            Console.WriteLine("Enter the Department name");
            string name = Console.ReadLine();
            try
            {
                string line, id = "", line1;
                using (StreamReader reader = new StreamReader(departfile))
                {
                    using (StreamReader reader1 = new StreamReader(filename))
                    {
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (line.Contains(name))
                            {
                                id = line.Substring(0, 20);
                            }
                        }

                        while ((line1 = reader1.ReadLine()) != null)
                        {
                            if (line1.Contains(id))
                            {
                                Console.WriteLine("EMP ID".PadLeft(20) + "EMP NAME".PadLeft(20) + "PHONE NO".PadLeft(20) + "DEPT ID".PadLeft(20) + "MANAGER ID".PadLeft(20));
                                Console.WriteLine(line1);
                                Console.WriteLine();
                            }
                        }
                    }
                }
            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        public void BasedOnManagerId()
        {
            Console.WriteLine("Enter the Manager Id");
            string manager = Console.ReadLine();
            try
            {
                string line, ids = "", line2;

                using (StreamReader reader = new StreamReader(projectsfile))
                {
                    using (StreamReader reader1 = new StreamReader(filename))
                    {
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (line.Contains(manager))
                            {
                                ids = line.Substring(0, 20);
                            }
                        }

                        while ((line2 = reader1.ReadLine()) != null)
                        {
                            if (line2.Contains(ids))
                            {
                                Console.WriteLine("EMP ID".PadLeft(20) + "EMP NAME".PadLeft(20) + "PHONE NO".PadLeft(20) + "DEPT ID".PadLeft(20) + "MANAGER ID".PadLeft(20));
                                Console.WriteLine(line2);
                                Console.WriteLine();
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void NoOfProjects()
        {
            Console.WriteLine("Enter the Department name");
            string name1 = Console.ReadLine();
            try
            {
                string line;
                using (StreamReader reader = new StreamReader(departfile))
                {
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Contains(name1))
                        {
                            var proj = line.Split(' ').Last();
                            Console.WriteLine("No of Projects: " + proj);
                        }
                    }
                }
            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        static void Main(string[] args)
        {
            EmployeeTest employee = new EmployeeTest();
            int ch;
            do
            {
                Console.WriteLine();
                Console.WriteLine("\t\t\t\t*****----- EMPLYOEE MANAGEMENT -----*****");
                Console.WriteLine();
                Console.WriteLine(" 1) Insert Employee Records ");
                Console.WriteLine(" 2) Insert Department Details ");
                Console.WriteLine(" 3) Insert Project Details ");
                Console.WriteLine(" 4) Search all Employees Department Name ");
                Console.WriteLine(" 5) Search all Employees by Manager Id ");
                Console.WriteLine(" 6) Search No of Projects by Department Name ");
                Console.WriteLine(" 7) Exit ");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Employee emp = new Employee();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename, true))
                            {
                                writer.Write(emp.ToString());
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;

                    case 2:
                        Department dept = new Department();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(departfile, true))
                            {
                                writer.Write(dept.ToString());
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;

                    case 3:
                        ProjectDetail projects1 = new ProjectDetail();
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(projectsfile, true))
                            {
                                writer.Write(projects1.ToString());
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;

                    case 4:
                        employee.BasedOnDepartName();
                        break;

                    case 5:
                        employee.BasedOnManagerId();
                        break;

                    case 6:
                        employee.NoOfProjects();
                        break;

                    case 7:
                        Environment.Exit(1);
                        break;

                    default: Console.WriteLine("Invalid Choice"); break;
                }
            } while (ch != 7);

            Console.ReadLine();
        }
    }
}
